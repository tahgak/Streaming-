const { execSync } = require('child_process');
const os = require('os');

const ports = [3010, 3000];

console.log('🔍 Vérification des ports...\n');

function freePort(port) {
  try {
    const platform = os.platform();
    let command;
    
    if (platform === 'win32') {
      const netstatOutput = execSync(`netstat -ano | findstr :${port}`, { encoding: 'utf-8' });
      if (netstatOutput.trim()) {
        console.log(`⚠️  Port ${port} est utilisé. Libération...`);
        const lines = netstatOutput.trim().split('\n');
        const pids = new Set();
        
        lines.forEach(line => {
          const parts = line.trim().split(/\s+/);
          const pid = parts[parts.length - 1];
          if (pid && /^\d+$/.test(pid)) {
            pids.add(pid);
          }
        });
        
        pids.forEach(pid => {
          try {
            execSync(`taskkill /F /PID ${pid}`, { stdio: 'ignore' });
            console.log(`✅ Processus ${pid} arrêté`);
          } catch (err) {
          }
        });
      } else {
        console.log(`✅ Port ${port} est libre`);
      }
    } else {
      try {
        const lsofOutput = execSync(`lsof -ti:${port}`, { encoding: 'utf-8', stdio: 'pipe' });
        if (lsofOutput.trim()) {
          console.log(`⚠️  Port ${port} est utilisé. Libération...`);
          const pids = lsofOutput.trim().split('\n');
          pids.forEach(pid => {
            try {
              execSync(`kill -9 ${pid}`, { stdio: 'ignore' });
              console.log(`✅ Processus ${pid} arrêté`);
            } catch (err) {
            }
          });
        } else {
          console.log(`✅ Port ${port} est libre`);
        }
      } catch (err) {
        console.log(`✅ Port ${port} est libre`);
      }
    }
  } catch (err) {
    console.log(`✅ Port ${port} est libre`);
  }
}

ports.forEach(port => {
  freePort(port);
});

console.log('\n✅ Ports vérifiés. Démarrage de l\'application...\n');

