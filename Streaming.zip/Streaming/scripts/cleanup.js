const fs = require('fs');
const path = require('path');

const middelwarePath = path.join(__dirname, '..', 'App-Serveur', 'middelware');
if (fs.existsSync(middelwarePath)) {
  try {
    fs.rmSync(middelwarePath, { recursive: true, force: true });
    console.log('✅ Dossier middelware supprimé');
  } catch (err) {
    console.error('❌ Erreur lors de la suppression:', err.message);
  }
} else {
  console.log('ℹ️  Dossier middelware n\'existe pas');
}

console.log('✅ Nettoyage terminé');

