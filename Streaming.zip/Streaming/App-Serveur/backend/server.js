require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
    console.error('ERROR: MONGODB_URI is not defined in .env file');
    process.exit(1);
}

mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

mongoose.connection.on('error', err => {
    console.error('MongoDB connection error:', err);
});


const authRouter = require('./routes/authRoutes');
app.use('/auth', authRouter);

const videoRouter = require('./routes/videoRoutes');
app.use('/videoRouter', videoRouter);

mongoose.connection.on('connected', () => {
    console.log('MongoDB connected successfully');
});

const PORT = process.env.PORT || 3010;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

