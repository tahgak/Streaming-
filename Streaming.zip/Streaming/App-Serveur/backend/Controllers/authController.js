require('dotenv').config();
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const SECRET_KEY = process.env.JWT_SECRET;

if (!SECRET_KEY) {
    console.error('ERROR: JWT_SECRET is not defined in .env file');
}

exports.signUp = async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).send({ error: 'Email et mot de passe requis' });
        }

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send({ error: 'Cet email est déjà utilisé' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ email, password: hashedPassword });
        await user.save();
        
        const token = jwt.sign({ id: user._id }, SECRET_KEY, { expiresIn: '30d' });
        
        res.status(201).send({ 
            message: 'Utilisateur créé avec succès',
            token 
        });
    } catch (err) {
        console.error('Erreur lors de la création:', err);
        res.status(400).send({
            error: err.message || "Échec de la création de l'utilisateur"
        });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).send({ error: 'Email et mot de passe requis' });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).send({ error: 'Email ou mot de passe incorrect' });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(400).send({ error: 'Email ou mot de passe incorrect' });
        }

        const token = jwt.sign({ id: user._id }, SECRET_KEY, { expiresIn: '30d' });
        res.send({ token });
    } catch (err) {
        console.error('Erreur lors de la connexion:', err);
        res.status(500).send({ error: 'Échec de la connexion' });
    }
};
exports.updatePassword = async (req, res) => {
    const { email, currentPassword, newPassword } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).send({ error: "Utilisateur non trouvé." });
        }

        const isMatch = await bcrypt.compare(currentPassword, user.password);
        if (!isMatch) {
            return res.status(401).send({ error: "Mot de passe actuel incorrect." });
        }

        const hashedNewPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedNewPassword;
        await user.save();

        res.status(200).send({ message: "Mot de passe mis à jour avec succès." });
    } catch (err) {
        res.status(500).send({ error: "Erreur interne du serveur." });
    }
};

exports.deleteAccount = async (req, res) => {
    try {
        const userId = req.userData?.id;

        if (!userId) {
            return res.status(401).json({ error: 'Utilisateur non authentifié' });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'Utilisateur non trouvé' });
        }

        const validPassword = await bcrypt.compare(req.body.password, user.password);
        if (!validPassword) {
            return res.status(400).json({ error: 'Mot de passe incorrect.' });
        }

        await User.findByIdAndDelete(userId);
        res.status(200).json({ message: 'Compte supprimé avec succès.' });
    } catch (error) {
        console.error("Erreur lors de la suppression du compte:", error);
        res.status(500).json({ error: 'Erreur lors de la suppression du compte.' });
    }
};

