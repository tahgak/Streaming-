const express = require('express');
const router = express.Router();
const videoController = require('../Controllers/videoController');
const verifyToken = require('../middleware/verifyToken');

router.post('/add', verifyToken, videoController.addVideo);
router.get('/videos', verifyToken, videoController.getAllVideos);
router.delete('/videos/:id', verifyToken, videoController.deleteVideo);

module.exports = router;

