const express = require('express');
const router = express.Router();
const authController = require('../Controllers/authController');
const verifyToken = require('../middleware/verifyToken');

router.post('/signUp', authController.signUp);
router.post('/signup', authController.signUp);

router.post('/login', authController.login);

router.put('/updatePassword', verifyToken, authController.updatePassword);
router.delete('/deleteAccount', verifyToken, authController.deleteAccount);

module.exports = router;

