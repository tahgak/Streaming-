require('dotenv').config();
const jwt = require('jsonwebtoken');

const SECRET_KEY = process.env.JWT_SECRET;

if (!SECRET_KEY) {
    console.error('ERROR: JWT_SECRET is not defined in .env file');
}

module.exports = (req, res, next) => {
    try {
        const authorizationHeader = req.headers.authorization;
        
        if (!authorizationHeader) {
            return res.status(401).json({ error: 'Token d\'authentification manquant' });
        }

        const token = authorizationHeader.split(' ')[1];
        
        if (!token) {
            return res.status(401).json({ error: 'Format de token invalide' });
        }

        const decoded = jwt.verify(token, SECRET_KEY);
        req.userData = { id: decoded.id };
        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({ error: 'Token invalide' });
        }
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'Token expiré' });
        }
        res.status(401).json({ error: 'Authentification échouée!' });
    }
};

