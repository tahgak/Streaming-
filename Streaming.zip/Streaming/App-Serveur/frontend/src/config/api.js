const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3010';

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: `${API_BASE_URL}/auth/login`,
    REGISTER: `${API_BASE_URL}/auth/signUp`,
    UPDATE_PASSWORD: `${API_BASE_URL}/auth/updatePassword`,
    DELETE_ACCOUNT: `${API_BASE_URL}/auth/deleteAccount`,
  },
  VIDEOS: {
    BASE: `${API_BASE_URL}/videoRouter`,
    GET_ALL: `${API_BASE_URL}/videoRouter/videos`,
    ADD: `${API_BASE_URL}/videoRouter/add`,
    DELETE: (id) => `${API_BASE_URL}/videoRouter/videos/${id}`,
  },
};

export default API_ENDPOINTS;

