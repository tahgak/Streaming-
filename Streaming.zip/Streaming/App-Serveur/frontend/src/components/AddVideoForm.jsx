import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addVideo } from '../services/videos';
import { useToast } from '../hooks/useToast';
import ToastContainer from './ToastContainer';

const AddVideoForm = ({ token }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    url: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toasts, removeToast, showSuccess, showError } = useToast();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await addVideo(
        formData.title,
        formData.description,
        formData.url,
        token
      );
      
      showSuccess('Video added successfully!');
      setFormData({
        title: '',
        description: '',
        url: ''
      });
      
      setTimeout(() => {
        navigate('/videos');
      }, 1000);
    } catch (err) {
      showError(err.response?.data?.message || 'Failed to add video');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      <form className="add-video-form" onSubmit={handleSubmit}>
        <h3>Add New Video</h3>
        
        <div className="form-group">
        <label htmlFor="title">Title</label>
        <input
          type="text"
          id="title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          required
          maxLength="100"
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="description">Description</label>
        <textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          required
          rows="4"
          maxLength="500"
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="url">Video URL</label>
        <input
          type="url"
          id="url"
          name="url"
          value={formData.url}
          onChange={handleChange}
          required
          placeholder="https://www.youtube.com/watch?v=..."
        />
      </div>
      
      <button 
        type="submit" 
        className="submit-button"
        disabled={isLoading}
        aria-busy={isLoading}
      >
        {isLoading ? 'Adding...' : 'Add Video'}
      </button>
      </form>
    </>
  );
};

export default AddVideoForm;