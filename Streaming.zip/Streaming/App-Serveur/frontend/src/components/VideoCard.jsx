import React, { useState } from 'react';

const getEmbedUrl = (url) => {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&]+)/);
  return match ? `https://www.youtube.com/embed/${match[1]}` : url;
};

const getThumbnailUrl = (url) => {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&]+)/);
  if (match) {
    return `https://img.youtube.com/vi/${match[1]}/maxresdefault.jpg`;
  }
  return null;
};

const getVideoId = (url) => {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&]+)/);
  return match ? match[1] : null;
};

const VideoCard = ({ video, onDelete }) => {
  const [showVideo, setShowVideo] = useState(false);
  const thumbnailUrl = getThumbnailUrl(video.url);
  const videoId = getVideoId(video.url);

  return (
    <div className="video-card">
      {thumbnailUrl && !showVideo && (
        <div 
          className="video-thumbnail"
          onClick={() => setShowVideo(true)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setShowVideo(true);
            }
          }}
          aria-label={`Play video: ${video.title}`}
        >
          <img 
            src={thumbnailUrl} 
            alt={video.title}
            loading="lazy"
            onError={(e) => {
              e.target.style.display = 'none';
            }}
          />
          <div className="play-overlay">
            <div className="play-button">▶</div>
          </div>
        </div>
      )}
      
      <div className="video-info">
        <h3>{video.title}</h3>
        <p className="video-description">{video.description}</p>
        {video.user?.email && (
          <p className="video-author">By: {video.user.email}</p>
        )}
      </div>

      <div className="video-actions">
        <button 
          onClick={() => setShowVideo(!showVideo)} 
          className="watch-button"
        >
          {showVideo ? 'Hide Video' : 'Watch Video'}
        </button>
        <button 
          onClick={() => onDelete(video._id)} 
          className="delete-button"
        >
          Delete
        </button>
      </div>

      {showVideo && (
        <div className="video-embed">
          <iframe
            src={getEmbedUrl(video.url)}
            title={video.title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            width="100%"
            height="315"
          />
        </div>
      )}
    </div>
  );
};

export default VideoCard;
