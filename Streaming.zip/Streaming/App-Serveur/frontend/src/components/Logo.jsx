import React, { useMemo } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import './Logo.css';

const Logo = ({ size = 'medium' }) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  
  const primaryColor = isDark ? '#ffd700' : '#4169e1';
  const secondaryColor = isDark ? '#ffffff' : '#1e3a8a';
  
  const sizeMap = {
    small: '24px',
    medium: '32px',
    large: '48px'
  };
  
  const iconSize = sizeMap[size] || sizeMap.medium;
  
  const gradientId = useMemo(() => `logoGradient-${isDark ? 'dark' : 'light'}`, [isDark]);
  const filterId = useMemo(() => 'logoGlow', []);

  return (
    <div className="logo-container" style={{ width: iconSize, height: iconSize }}>
      <svg
        width={iconSize}
        height={iconSize}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="logo-svg"
        aria-label="streamVid Logo"
      >
        <defs>
          <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={primaryColor} stopOpacity="1" />
            <stop offset="100%" stopColor={isDark ? '#ffed4e' : '#1e3a8a'} stopOpacity="1" />
          </linearGradient>
          <filter id={filterId}>
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        <rect
          x="15"
          y="25"
          width="70"
          height="50"
          rx="8"
          fill={`url(#${gradientId})`}
          className="logo-main"
        />
        
        <rect
          x="20"
          y="30"
          width="25"
          height="8"
          rx="4"
          fill="rgba(255, 255, 255, 0.3)"
          className="logo-highlight"
        />
        
        <circle
          cx="50"
          cy="50"
          r="18"
          fill={secondaryColor}
          className="logo-lens"
          filter={`url(#${filterId})`}
        />
        
        <circle
          cx="50"
          cy="50"
          r="18"
          fill="none"
          stroke={primaryColor}
          strokeWidth="2"
          opacity="0.6"
        />
        
        <circle
          cx="50"
          cy="50"
          r="12"
          fill={primaryColor}
          className="logo-lens-inner"
        />
        
        <circle
          cx="45"
          cy="45"
          r="4"
          fill="rgba(255, 255, 255, 0.4)"
        />
        
        <circle
          cx="70"
          cy="35"
          r="6"
          fill={isDark ? '#ff4444' : '#dc2626'}
          className="logo-record"
        />
        
        <g className="logo-rays">
          <path
            d="M 50 20 L 50 30"
            stroke={primaryColor}
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.6"
          />
          <path
            d="M 20 50 L 30 50"
            stroke={primaryColor}
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.6"
          />
          <path
            d="M 50 70 L 50 80"
            stroke={primaryColor}
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.6"
          />
          <path
            d="M 70 50 L 80 50"
            stroke={primaryColor}
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.6"
          />
        </g>
        
        <circle
          cx="25"
          cy="30"
          r="2"
          fill={primaryColor}
          opacity="0.5"
          className="logo-particle"
        />
        <circle
          cx="75"
          cy="65"
          r="2"
          fill={primaryColor}
          opacity="0.5"
          className="logo-particle"
        />
      </svg>
    </div>
  );
};

export default Logo;

