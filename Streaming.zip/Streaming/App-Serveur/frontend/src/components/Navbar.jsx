import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import ThemeToggle from './ThemeToggle';
import Logo from './Logo';

const Navbar = ({ isAuthenticated, onLogout }) => {
  const location = useLocation();
  const userEmail = localStorage.getItem('userEmail');

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/" className="brand-link">
          <Logo size="medium" />
          <span className="brand-text">streamVid</span>
        </Link>
      </div>
      <div className="navbar-links">
        <ThemeToggle />
        {!isAuthenticated ? (
          <>
            <Link 
              to="/login" 
              className={location.pathname === '/login' ? 'active' : ''}
            >
              Login
            </Link>
            <Link 
              to="/register"
              className={location.pathname === '/register' ? 'active' : ''}
            >
              Register
            </Link>
          </>
        ) : (
          <>
            <Link 
              to="/videos"
              className={location.pathname === '/videos' || location.pathname === '/' ? 'active' : ''}
            >
              📹 Videos
            </Link>
            <Link 
              to="/add"
              className={location.pathname === '/add' ? 'active' : ''}
            >
              ➕ Add Video
            </Link>
            <Link 
              to="/profile"
              className={location.pathname === '/profile' ? 'active' : ''}
            >
              👤 {userEmail ? userEmail.split('@')[0] : 'Profile'}
            </Link>
            <button onClick={onLogout} className="logout-btn">
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;