import React, { useState } from 'react';
import { updatePassword } from '../services/auth';
import { useToast } from '../hooks/useToast';
import ToastContainer from '../components/ToastContainer';

const UpdatePassword = ({ token }) => {
  const userEmail = localStorage.getItem('userEmail') || '';
  const { toasts, removeToast, showSuccess, showError } = useToast();

  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.currentPassword || !formData.newPassword || !formData.confirmPassword) {
      showError('All fields are required');
      return;
    }

    if (formData.newPassword !== formData.confirmPassword) {
      showError('New passwords do not match');
      return;
    }

    if (formData.newPassword.length < 6) {
      showError('Password must be at least 6 characters');
      return;
    }

    if (formData.currentPassword === formData.newPassword) {
      showError('New password must be different from current password');
      return;
    }

    if (!userEmail) {
      showError('User email not found. Please log in again.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await updatePassword(
        userEmail,                  
        formData.currentPassword,
        formData.newPassword,
        token
      );
      
      if (response.success) {
        showSuccess('Password updated successfully!');
        setFormData({
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
      } else {
        showError(response.message || 'Failed to update password');
      }
    } catch (err) {
      console.error('Password update error:', err);
      showError(err.response?.data?.message || err.message || 'Failed to update password');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="account-section">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      <h2>Update Password</h2>
      <p className="email-display">Updating password for: {userEmail}</p>
      
      <form onSubmit={handleSubmit} className="account-form">
        <div className="form-group">
          <label htmlFor="currentPassword">Current Password:</label>
          <input
            type="password"
            id="currentPassword"
            name="currentPassword"
            value={formData.currentPassword}
            onChange={handleChange}
            required
            autoComplete="current-password"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="newPassword">New Password:</label>
          <input
            type="password"
            id="newPassword"
            name="newPassword"
            value={formData.newPassword}
            onChange={handleChange}
            required
            minLength="6"
            autoComplete="new-password"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm New Password:</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
            minLength="6"
            autoComplete="new-password"
          />
        </div>
        
        <button 
          type="submit" 
          className="update-button"
          disabled={isLoading || !userEmail}
          aria-busy={isLoading}
        >
          {isLoading ? 'Updating...' : 'Update Password'}
        </button>
      </form>
    </div>
  );
};

export default UpdatePassword;