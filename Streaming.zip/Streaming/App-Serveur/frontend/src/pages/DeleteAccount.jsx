import React, { useState } from 'react';
import { deleteAccount } from '../services/auth';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../hooks/useToast';
import ToastContainer from '../components/ToastContainer';

const DeleteAccount = ({ token }) => {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toasts, removeToast, showError, showSuccess } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!password) {
      showError('Please enter your password to confirm');
      return;
    }

    setIsLoading(true);

    try {
      await deleteAccount(password, token);
      localStorage.removeItem('token');
      localStorage.removeItem('userEmail');
      showSuccess('Account deleted successfully');
      setTimeout(() => {
        navigate('/login');
        window.location.reload();
      }, 1000);
    } catch (err) {
      showError(err.response?.data?.message || 'Failed to delete account');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="account-section">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      <h2>Delete Account</h2>
      <p className="warning-text">
        Warning: This action is irreversible. All your data will be permanently deleted.
      </p>
      
      <form onSubmit={handleSubmit} className="account-form">
        <div className="form-group">
          <label htmlFor="password">Confirm Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            placeholder="Enter your password to confirm"
          />
        </div>
        
        <button 
          type="submit" 
          className="delete-button"
          disabled={isLoading}
        >
          {isLoading ? 'Processing...' : 'Permanently Delete Account'}
        </button>
      </form>
    </div>
  );
};

export default DeleteAccount;