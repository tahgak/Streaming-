import React from 'react';
import AddVideoForm from '../components/AddVideoForm';

const AddVideoPage = () => {
  const token = localStorage.getItem('token');

  return (
    <div className="add-video-page">
      <div className="page-header">
        <h1>Add New Video</h1>
        <p>Share your favorite videos with the community</p>
      </div>
      
      <div className="form-container">
        <AddVideoForm token={token} />
      </div>
    </div>
  );
};

export default AddVideoPage;