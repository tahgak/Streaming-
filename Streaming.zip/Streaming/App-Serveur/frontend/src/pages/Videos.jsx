import React, { useState, useEffect, useMemo } from 'react';
import { getVideos, deleteVideo } from '../services/videos';
import VideoCard from '../components/VideoCard';
import Loader from '../components/Loader';
import { useToast } from '../hooks/useToast';
import ToastContainer from '../components/ToastContainer';

const Videos = ({ token }) => {
  const [videos, setVideos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const { toasts, removeToast, showSuccess, showError } = useToast();

  useEffect(() => {
    const fetchVideos = async () => {
      setIsLoading(true);
      try {
        const data = await getVideos(token);
        setVideos(data);
      } catch (err) {
        console.error('Error fetching videos:', err);
        showError('Failed to load videos');
        setVideos([]);
      } finally {
        setIsLoading(false);
      }
    };
    if (token) {
      fetchVideos();
    }
  }, [token]);

  const filteredAndSortedVideos = useMemo(() => {
    let filtered = videos;

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(video =>
        video.title.toLowerCase().includes(query) ||
        video.description.toLowerCase().includes(query)
      );
    }

    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
        case 'oldest':
          return new Date(a.createdAt || 0) - new Date(b.createdAt || 0);
        case 'title-asc':
          return a.title.localeCompare(b.title);
        case 'title-desc':
          return b.title.localeCompare(a.title);
        default:
          return 0;
      }
    });

    return sorted;
  }, [videos, searchQuery, sortBy]);

  const handleDelete = async (videoId, videoTitle) => {
    if (!window.confirm(`Are you sure you want to delete "${videoTitle}"?`)) {
      return;
    }

    try {
      await deleteVideo(videoId, token);
      setVideos(videos.filter(video => video._id !== videoId));
      showSuccess('Video deleted successfully');
    } catch (err) {
      console.error('Error deleting video:', err);
      showError('Failed to delete video');
    }
  };

  if (isLoading) {
    return <Loader message="Loading videos..." />;
  }

  return (
    <div className="videos-page">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      
      <div className="hero">
        <h1>Video Library</h1>
        <p>Discover and manage your video collection</p>
      </div>

      <div className="videos-stats">
        <div className="stat-card">
          <div className="stat-value">{videos.length}</div>
          <div className="stat-label">Total Videos</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{filteredAndSortedVideos.length}</div>
          <div className="stat-label">Showing</div>
        </div>
      </div>

      <div className="videos-controls">
        <div className="search-container">
          <input
            type="text"
            placeholder="Search videos by title or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>
        <div className="sort-container">
          <label htmlFor="sort-select">Sort by:</label>
          <select
            id="sort-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="sort-select"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="title-asc">Title (A-Z)</option>
            <option value="title-desc">Title (Z-A)</option>
          </select>
        </div>
      </div>
      
      <div className="videos-grid">
        {filteredAndSortedVideos.length > 0 ? (
          filteredAndSortedVideos.map(video => (
            <VideoCard 
              key={video._id} 
              video={video} 
              onDelete={(id) => handleDelete(id, video.title)} 
              canDelete={true} 
            />
          ))
        ) : (
          <div className="no-videos">
            {searchQuery ? (
              <>
                <p>No videos found matching "{searchQuery}"</p>
                <button 
                  onClick={() => setSearchQuery('')}
                  className="btn-primary"
                >
                  Clear Search
                </button>
              </>
            ) : (
              <p>No videos available. Start by adding your first video!</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Videos;