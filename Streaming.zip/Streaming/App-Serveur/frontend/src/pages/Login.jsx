import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '../services/auth';
import { useToast } from '../hooks/useToast';
import ToastContainer from '../components/ToastContainer';

const Login = ({ setToken }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toasts, removeToast, showSuccess, showError } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const data = await login(email, password);
      if (data.token) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('userEmail', email); 
        
        setToken(data.token);
        showSuccess('Login successful!');
        setTimeout(() => navigate('/videos'), 500);
      } else {
        showError(data.message || 'Login failed');
      }
    } catch (err) {
      showError(err.response?.data?.message || 'An error occurred during login');
      console.error('Login error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-form">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          autoComplete="username" 
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          autoComplete="current-password" 
        />
        <button type="submit" disabled={isLoading}>
          {isLoading ? 'Logging in...' : 'Login'}
        </button>
      </form>
      <p className="auth-switch">
        Don't have an account? <a href="/register">Register here</a>
      </p>
    </div>
  );
};

export default Login;