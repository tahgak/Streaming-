import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Register from './pages/Register';
import Videos from './pages/Videos';
import Profile from './pages/Profile';
import DeleteAccount from './pages/DeleteAccount';
import AddVideoPage from './pages/AddVideoPage';
import { useToast } from './hooks/useToast';
import ToastContainer from './components/ToastContainer';
import './App.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const { toasts, removeToast, showSuccess } = useToast();

  useEffect(() => {
    if (token) {
      setIsAuthenticated(true);
    } else {
      setIsAuthenticated(false);
    }
  }, [token]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userEmail');
    setToken('');
    setIsAuthenticated(false);
    showSuccess('Logged out successfully');
  };

  return (
    <ThemeProvider>
      <Router>
        <Navbar isAuthenticated={isAuthenticated} onLogout={handleLogout} />
        <ToastContainer toasts={toasts} removeToast={removeToast} />
        <div className="container">
          <Routes>
            <Route path="/" element={isAuthenticated ? <Videos token={token} /> : <Navigate to="/login" />} />
            <Route 
              path="/login" 
              element={isAuthenticated ? <Navigate to="/videos" /> : <Login setToken={setToken} />} 
            />
            <Route 
              path="/register" 
              element={isAuthenticated ? <Navigate to="/videos" /> : <Register setToken={setToken} />} 
            />
            <Route 
              path="/videos" 
              element={isAuthenticated ? <Videos token={token} /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/profile" 
              element={isAuthenticated ? <Profile token={token} /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/delete" 
              element={isAuthenticated ? <DeleteAccount token={token} /> : <Navigate to="/login" />} 
            />
            <Route 
             path="/add"
             element={isAuthenticated ? <AddVideoPage token={token} /> : <Navigate to="/login" />}
            />
          </Routes>
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;