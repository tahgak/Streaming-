import { API_ENDPOINTS } from '../config/api';

const authenticatedRequest = async (url, options = {}) => {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Erreur serveur' }));
    throw new Error(errorData.error || errorData.message || 'Erreur lors de la requête');
  }

  return response.json();
};

export const getVideos = async (token) => {
  return authenticatedRequest(API_ENDPOINTS.VIDEOS.GET_ALL, {
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });
};

export const addVideo = async (title, description, url, token) => {
  return authenticatedRequest(API_ENDPOINTS.VIDEOS.ADD, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({ title, description, url }),
  });
};

export const deleteVideo = async (videoId, token) => {
  return authenticatedRequest(API_ENDPOINTS.VIDEOS.DELETE(videoId), {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });
};