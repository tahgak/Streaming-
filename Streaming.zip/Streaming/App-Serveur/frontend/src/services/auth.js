import { API_ENDPOINTS } from '../config/api';

const apiRequest = async (url, options = {}) => {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Erreur serveur' }));
    throw new Error(errorData.error || errorData.message || 'Erreur lors de la requête');
  }

  return response.json();
};

export const login = async (email, password) => {
  return apiRequest(API_ENDPOINTS.AUTH.LOGIN, {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
};

export const register = async (email, password) => {
  return apiRequest(API_ENDPOINTS.AUTH.REGISTER, {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
};

export const updatePassword = async (email, currentPassword, newPassword, token) => {
  return apiRequest(API_ENDPOINTS.AUTH.UPDATE_PASSWORD, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({ email, currentPassword, newPassword }),
  });
};

export const deleteAccount = async (password, token) => {
  return apiRequest(API_ENDPOINTS.AUTH.DELETE_ACCOUNT, {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({ password }),
  });
};